import React from 'react';
import { View, StyleSheet } from 'react-native';

/**
 * Arrow that starts at `origin` (the AimPad center),
 * points along `direction`, and lengthens with `power`.
 */
export default function AimArrow({ visible, direction, power = 0, origin, radius = 60 }) {
  if (!visible || !origin) return null;

  // Accept both {dx,dy} and {x,y}
  const vx = (direction?.dx ?? direction?.x ?? 0);
  const vy = (direction?.dy ?? direction?.y ?? -1);

  // Normalize
  const m = Math.hypot(vx, vy) || 1;
  const ux = vx / m;
  const uy = vy / m;

  // Power -> length
  const clamped = Math.max(0, Math.min(1, power));
  const base = radius * 0.8;
  const extra = radius * 1.2;
  const length = base + extra * clamped;
  const thickness = Math.max(4, radius * 0.18);

  // Angle for React Native (degrees)
  const angleDeg = (Math.atan2(uy, ux) * 180) / Math.PI;

  const { x: ox, y: oy } = origin;

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {/* Wrapper at the pad center; rotate here so the pivot is the origin */}
      <View
        style={{
          position: 'absolute',
          left: ox,
          top: oy,
          width: 0,
          height: 0,
          transform: [{ rotate: `${angleDeg}deg` }],
          zIndex: 999,
        }}
      >
        {/* The bar starts at (0,0) and extends to +X after rotation */}
        <View
          style={{
            position: 'absolute',
            left: 0,
            top: -thickness / 2,
            width: length,
            height: thickness,
            backgroundColor: 'rgba(255,0,0,0.55)',
            borderRadius: thickness / 2,
          }}
        />
      </View>
    </View>
  );
}
