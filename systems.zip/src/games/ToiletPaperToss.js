// ToiletPaperToss.js
// Expo React Native + react-native-game-engine + matter-js starter for the Toilet Paper Toss game
// Features:
// - Slingshot-style aiming (drag back like Angry Birds)
// - Ping-pong charge bar (0→100→0 while holding)
// - Toilet paper (circle body) bounces off walls/ceiling/toilet
// - Touching the ground ends the turn and resets the paper
// - Tunable physics so the paper actually FLIES

import React, { useRef, useState, useEffect } from 'react';
import { StyleSheet, View, Dimensions, Text, Image, ImageBackground, TouchableOpacity, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GameEngine } from 'react-native-game-engine';
import Matter from 'matter-js';
import { Audio } from 'expo-av';
import Svg, { Polygon, Circle as SvgCircle, Rect } from 'react-native-svg';
import AimPad from '../../components/AimPad';
import TrajectoryOverlay from '../../components/TrajectoryOverlay';
import PowerBar from '../../components/PowerBar';

// Set up poly-decomp for Matter.js concave shapes
import decomp from 'poly-decomp';
Matter.Common.setDecomp(decomp);

const { width: WIDTH, height: HEIGHT } = Dimensions.get('window');

// Sound effects
let dingSound = null;
let waterDropSound = null;

const loadSounds = async () => {
  try {
    const { sound: ding } = await Audio.Sound.createAsync(
      require('../../assets/ding.mp3')
    );
    dingSound = ding;
    
    const { sound: water } = await Audio.Sound.createAsync(
      require('../../assets/water_drop.mp3')
    );
    waterDropSound = water;
  } catch (error) {
    console.log('Could not load sound effect:', error);
  }
};

const playDingSound = async () => {
  if (dingSound) {
    try {
      await dingSound.replayAsync();
    } catch (error) {
      console.log('Could not play sound:', error);
    }
  }
};

const playWaterDropSound = async () => {
  if (waterDropSound) {
    try {
      await waterDropSound.replayAsync();
    } catch (error) {
      console.log('Could not play water drop sound:', error);
    }
  }
};

/******************** Utility Renderers ********************/
const Circle = ({ body, color = '#ffffff', radius = 16, imageSource, hidden }) => {
  if (hidden) return null;
  const x = body.position.x - radius;
  const y = body.position.y - radius;
  return (
    <View style={[{
      position: 'absolute',
      left: x,
      top: y,
      width: radius * 2,
      height: radius * 2,
      borderRadius: radius,
      backgroundColor: color,
      borderWidth: 2,
      borderColor: '#222'
    }]}>
      {imageSource && (
        <Image
          source={imageSource}
          style={{
            width: '100%',
            height: '100%',
            borderRadius: radius,
          }}
          resizeMode="contain"
        />
      )}
    </View>
  );
};

const Box = ({ body, color = '#888' }) => {
  const { min, max } = body.bounds;
  const w = max.x - min.x;
  const h = max.y - min.y;
  const x = min.x;
  const y = min.y;
  return (
    <View style={[{
      position: 'absolute',
      left: x,
      top: y,
      width: w,
      height: h,
      backgroundColor: color,
      borderWidth: 1,
      borderColor: '#333'
    }]} />
  );
};

// AimIndicator and ChargeBar now imported from components/

// Toilet sprite bound to physics body
const ToiletSprite = ({ body }) => {
  const { min, max } = body.bounds;
  const w = max.x - min.x;
  const h = max.y - min.y;
  const x = min.x;
  const y = min.y;
  return (
    <View style={{ position: 'absolute', left: x, top: y, width: w, height: h }}>
      <Image source={require('../../assets/toilet.png')} style={{ width: '100%', height: '100%' }} resizeMode="contain" />
    </View>
  );
};

// Debug: Visualize static bodies to find invisible walls
const StaticBodiesOverlay = ({ engine }) => {
  if (!engine) return null;
  const bodies = Matter.Composite.allBodies(engine.world).filter(b => b.isStatic);
  return (
    <>
      {bodies.map((b, i) => {
        const bb = b.bounds;
        const left = bb.min.x, top = bb.min.y;
        const width = bb.max.x - bb.min.x, height = bb.max.y - bb.min.y;
        // Skip huge offscreen parking rects if you have any
        if (!isFinite(left) || !isFinite(top) || width <= 0 || height <= 0) return null;
        return (
          <View key={i} style={{
            position: "absolute",
            left, top, width, height,
            borderWidth: 2,
            borderColor: "rgba(255,0,0,0.8)",
            backgroundColor: "rgba(255,0,0,0.15)",
            zIndex: 999,
          }} />
        );
      })}
    </>
  );
};

// Bowl hitbox debug overlay
const BowlHitboxOverlay = ({ engine }) => {
  if (!engine) return null;
  
  const bowlBodies = Matter.Composite.allBodies(engine.world).filter(b => 
    b.label === "BOWL_SIDE_L" || b.label === "BOWL_SIDE_R" || b.label === "BOWL_BOTTOM" || b.label === "BOWL_SENSOR"
  );
  
  // Debug: Log bowl bodies found (only once)
  if (bowlBodies.length === 0) {
    console.log("BOWL HITBOX DEBUG: No bowl bodies found in world");
  }
  
  if (bowlBodies.length === 0) return null;

  return (
    <View style={{
      position: "absolute",
      left: 0,
      top: 0,
      width: WIDTH,
      height: HEIGHT,
      zIndex: 998,
      pointerEvents: "none", // Allow touch events to pass through
    }}>
      <Svg width={WIDTH} height={HEIGHT}>
        {bowlBodies.map((body, index) => {
          if (body.label === "BOWL_MAIN") {
            // Circle for main bowl
            return (
              <SvgCircle
                key={index}
                cx={body.position.x}
                cy={body.position.y}
                r={body.circleRadius}
                fill="rgba(255,0,0,0.2)"
                stroke="rgba(255,0,0,1)"
                strokeWidth="3"
              />
            );
          } else {
            // Rectangle for walls and top
            const bounds = body.bounds;
            const width = bounds.max.x - bounds.min.x;
            const height = bounds.max.y - bounds.min.y;
            return (
              <Rect
                key={index}
                x={bounds.min.x}
                y={bounds.min.y}
                width={width}
                height={height}
                fill="rgba(255,0,0,0.2)"
                stroke="rgba(255,0,0,1)"
                strokeWidth="3"
              />
            );
          }
        })}
      </Svg>
    </View>
  );
};

// Bottom-center Press button used to start charging/aiming
const ShootButton = ({ held, onLayoutRect, onPressIn, onDrag, onRelease }) => {
  const size = 96;
  const viewRef = React.useRef(null);

  const reportLayout = () => {
    if (viewRef.current && typeof viewRef.current.measureInWindow === 'function') {
      viewRef.current.measureInWindow((x, y, width, height) => {
        const rect = { x, y, w: width, h: height };
        const anchor = { x: x + width / 2, y: y }; // top-center of button
        onLayoutRect && onLayoutRect(rect, anchor);
      });
    }
  };

  return (
    <View
      ref={viewRef}
      style={styles.shootButton}
      onLayout={reportLayout}
      onStartShouldSetResponder={() => true}
      onResponderGrant={(e) => {
        reportLayout();
        const { pageX: x, pageY: y } = e.nativeEvent;
        onPressIn && onPressIn({ x, y });
      }}
      onResponderMove={(e) => {
        const { pageX: x, pageY: y } = e.nativeEvent;
        onDrag && onDrag({ x, y });
      }}
      onResponderRelease={() => onRelease && onRelease()}
    >
      <Image
        source={held ? require('../../assets/button_depressed.png') : require('../../assets/button.png')}
        style={{ width: size, height: size }}
        resizeMode="contain"
      />
    </View>
  );
};

/******************** Constants ********************/
const CONSTANTS = {
  TP_RADIUS: 18,
  START_X: WIDTH * 0.50, // Start center horizontally
  START_Y: HEIGHT - 24 - 56 - 50, // Above the AimPad
  MAX_AIM_LEN: 160, // px drag clamp
  MAX_IMPULSE: 0.12, // scale for Matter.applyForce (tune 0.04..0.14)
  CHARGE_SPEED: 170, // percent per second
  GRAVITY_Y: 0.15, // Fine-tuned gravity for optimal travel time
};

/******************** World Factory ********************/

// Clean arena builder
const buildArena = (engine, W, H, tpBody) => {
  const world = engine.world;

  // Remove all bodies except TP
  Matter.Composite.allBodies(world).forEach(b => {
    if (b !== tpBody) Matter.World.remove(world, b);
  });

  // Add floor, ceiling, left wall, right wall
  const wall = { isStatic: true, label: "BOUNDARY" };
  const walls = [
    Matter.Bodies.rectangle(W / 2, H + 40, W, 80, wall),   // floor
    Matter.Bodies.rectangle(W / 2, -40, W, 80, wall),      // ceiling
    Matter.Bodies.rectangle(-40, H / 2, 80, H, wall),      // left
    Matter.Bodies.rectangle(W + 40, H / 2, 80, H, wall),   // right
  ];
  Matter.World.add(world, walls);
};

// Remove any old rim that blocks the opening
const removeOldRims = (engine) => {
  const world = engine.world;
  Matter.Composite.allBodies(world).forEach(b => {
    if (["BOWL_RIM", "BOWL", "BOWL_RING"].includes(b.label)) {
      Matter.World.remove(world, b);
    }
  });
};

// Add an open-top bowl (left + right + curved bottom + sensor)
const addOpenBowl = (engine, bx, by, r = 42) => {
  const world = engine.world;
  const thickness = 16;               // wall thickness (px)
  const tilt = 0.35;                  // wall inward tilt (radians ~20°)

  // Material tuned to "slide in", not bounce out
  const mat = { 
    isStatic: true, 
    restitution: 0.05, 
    friction: 0.25, 
    frictionStatic: 0.9 
  };

  // Left inner wall (tilted inward)
  const left = Matter.Bodies.rectangle(bx - r * 0.9, by + r * 0.1, thickness, r * 1.6, {
    ...mat, 
    angle: -tilt, 
    label: "BOWL_SIDE_L"
  });

  // Right inner wall (tilted inward)
  const right = Matter.Bodies.rectangle(bx + r * 0.9, by + r * 0.1, thickness, r * 1.6, {
    ...mat, 
    angle: tilt, 
    label: "BOWL_SIDE_R"
  });

  // Curved bottom (a circle placed below the hole)
  // This gives a smooth slide; top is OPEN because we don't add any top collider.
  const bottom = Matter.Bodies.circle(bx, by + r * 0.8, r * 0.475, { // Moved up from 0.6 to 0.8 to bring top edge down
    ...mat, 
    label: "BOWL_BOTTOM"
  });

  // Scoring sensor (no physical push) — smaller than the visual hole
  const sensor = Matter.Bodies.circle(bx, by + r * 0.2, r * 0.55, {
    isStatic: true, 
    isSensor: true, 
    label: "BOWL_SENSOR"
  });

  Matter.World.add(world, [left, right, bottom, sensor]);

  // Debug: Log the bowl components
  console.log("OPEN BOWL COMPONENTS CREATED:", [
    { label: "BOWL_SIDE_L", x: left.position.x.toFixed(1), y: left.position.y.toFixed(1) },
    { label: "BOWL_SIDE_R", x: right.position.x.toFixed(1), y: right.position.y.toFixed(1) },
    { label: "BOWL_BOTTOM", x: bottom.position.x.toFixed(1), y: bottom.position.y.toFixed(1) },
    { label: "BOWL_SENSOR", x: sensor.position.x.toFixed(1), y: sensor.position.y.toFixed(1) },
  ]);

  // Return the bowl bodies for movement control
  return { left, right, bottom, sensor, centerX: bx, centerY: by, radius: r };
};

// Wire up scoring when the roll enters the bowl
const wireScoring = (engine, addScoreCallback) => {
  Matter.Events.on(engine, "collisionStart", (e) => {
    e.pairs.forEach(({ bodyA, bodyB }) => {
      const a = bodyA.label, b = bodyB.label;
      if ((a === "BOWL_SENSOR" && b === "TP") || (b === "BOWL_SENSOR" && a === "TP")) {
        console.log("SCORE! TP entered the bowl!");
        
        // Hide the TP sprite by setting it to off-screen
        const tpBody = a === "TP" ? bodyA : bodyB;
        Matter.Body.setPosition(tpBody, { x: -9999, y: -9999 });
        
        // Play water drop sound effect
        playWaterDropSound();
        
        // Add point
        addScoreCallback();
      }
    });
  });
};

// Create TP body
const createTP = () => {
  return Matter.Bodies.circle(-9999, -9999, CONSTANTS.TP_RADIUS, {
    label: "TP",
    restitution: 0.45,
    friction: 0.05,
    frictionAir: 0.012,
    density: 0.0016,
    isStatic: true, // keep the roll fixed until launch
  });
};

const setupWorld = (addScoreCallback) => {
  const engine = Matter.Engine.create({ enableSleeping: false });
  const world = engine.world;
  world.gravity.y = CONSTANTS.GRAVITY_Y;

  // Create TP first
  const tp = createTP();

  // Build clean arena
  buildArena(engine, WIDTH, HEIGHT, tp);
  
  // Remove any old rim that blocks the opening
  removeOldRims(engine);
  
  // Add open-top toilet bowl and store the bodies for movement
  const bowlBodies = addOpenBowl(engine, WIDTH / 2, HEIGHT * 0.40, 42); // Moved back up from 0.45 to 0.40 (50% of the way back)
  
  // Wire up scoring
  wireScoring(engine, addScoreCallback);

  // Add TP body to the world
  Matter.World.add(world, tp);
  console.log('TP body added to world');

  // Remove any old debug colliders
  Matter.Composite.allBodies(engine.world).forEach(b => {
    if (!["BOUNDARY", "BOWL_SIDE_L", "BOWL_SIDE_R", "BOWL_BOTTOM", "BOWL_SENSOR", "TP"].includes(b.label)) {
      Matter.World.remove(engine.world, b);
    }
  });

  // Verify the arena
  const logStatics = (engine) => {
    const statics = Matter.Composite.allBodies(engine.world).filter(b => b.isStatic);
    console.log("CLEAN STATIC BODIES:", statics.map(b => ({
      label: b.label,
      x: b.position.x.toFixed(1),
      y: b.position.y.toFixed(1),
      w: (b.bounds.max.x - b.bounds.min.x).toFixed(1),
      h: (b.bounds.max.y - b.bounds.min.y).toFixed(1),
    })));
  };
  logStatics(engine);

  return { engine, world, bodies: { tp, bowlBodies } };
};

/******************** Systems ********************/
// Fixed-step physics
const Physics = (entities, { time }) => {
  const engine = entities.physics.engine;
  Matter.Engine.update(engine, time?.delta || 16.666);
  return entities;
};

// ChargeSystem now imported from systems/ChargeSystem.js

// Handle end-turn when touching ground
const CollisionSystem = (entities, { events }) => {
  // We subscribe to Matter collision events once in App; here just read flags from entities.state
  return entities;
};

// Moving toilet system
const MovingToiletSystem = (entities, { time }) => {
  const { engine, world, bodies } = entities.physics;
  const bowlBodies = bodies?.bowlBodies;
  
  if (!bowlBodies) {
    console.log('MovingToiletSystem: No bowlBodies found');
    return entities;
  }
  
  // Initialize movement state if not exists
  if (!entities.toiletMovement) {
    const centerX = WIDTH / 2; // Start exactly in the center
    entities.toiletMovement = {
      direction: -1, // Start moving left first
      speed: 0.8, // pixels per frame
      leftBound: centerX - 150, // 150 pixels left from center
      rightBound: centerX + 150, // 150 pixels right from center
      currentX: centerX
    };
  }
  
  const movement = entities.toiletMovement;
  
  // Update position
  movement.currentX += movement.direction * movement.speed;
  
  // Check bounds and reverse direction
  if (movement.currentX <= movement.leftBound) {
    movement.currentX = movement.leftBound;
    movement.direction = 1; // start moving right
  } else if (movement.currentX >= movement.rightBound) {
    movement.currentX = movement.rightBound;
    movement.direction = -1; // start moving left
  }
  
  // Move all bowl bodies together
  const newCenterX = movement.currentX;
  const centerY = bowlBodies.centerY;
  const r = bowlBodies.radius;
  const thickness = 16;
  const tilt = 0.35;
  
  // Update left wall position
  Matter.Body.setPosition(bowlBodies.left, {
    x: newCenterX - r * 0.9,
    y: centerY + r * 0.1
  });
  
  // Update right wall position
  Matter.Body.setPosition(bowlBodies.right, {
    x: newCenterX + r * 0.9,
    y: centerY + r * 0.1
  });
  
  // Update bottom position
  Matter.Body.setPosition(bowlBodies.bottom, {
    x: newCenterX,
    y: centerY + r * 0.8
  });
  
  // Update sensor position
  Matter.Body.setPosition(bowlBodies.sensor, {
    x: newCenterX,
    y: centerY + r * 0.2
  });
  
  // Update the stored center position
  bowlBodies.centerX = newCenterX;
  
  // Debug: Log movement every 60 frames (about once per second)
  if (!entities.toiletMovement.frameCount) {
    entities.toiletMovement.frameCount = 0;
  }
  entities.toiletMovement.frameCount++;
  if (entities.toiletMovement.frameCount % 60 === 0) {
    console.log('MovingToiletSystem: Toilet position:', newCenterX.toFixed(1), 'direction:', movement.direction);
  }
  
  return entities;
};

/******************** Main Component ********************/
export default function ToiletPaperToss({ onGameComplete, gameMode }) {
  const gameRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [misses, setMisses] = useState(0);
  const [timeLeft, setTimeLeft] = useState(gameMode === 'quick-flush' ? 60 : 0);
  const [gameOverVisible, setGameOverVisible] = useState(false);

  const [isMuted, setIsMuted] = useState(false);
  const [settingsVisible, setSettingsVisible] = useState(false);
  const [tpPos, setTpPos] = useState({ x: -9999, y: -9999 });
  const [tpVisible, setTpVisible] = useState(false);
  const [toiletPos, setToiletPos] = useState({ x: WIDTH / 2, y: HEIGHT * 0.35 });
  


  // Use ref to store scoring callback
  const addScoreRef = useRef(null);

  const [enginePkg] = useState(() => {
    const worldSetup = setupWorld(() => {
      if (addScoreRef.current) {
        addScoreRef.current();
      }
    });
    
    // Temporary fix: Trigger a fake attempt when starting a new game
    if (worldSetup.bodies?.tp) {
      const spawn = { x: 195, y: 745 }; // adjust to AimPad center if needed

      Matter.Body.setStatic(worldSetup.bodies.tp, false);
      Matter.Sleeping.set(worldSetup.bodies.tp, false);
      Matter.Body.setPosition(worldSetup.bodies.tp, spawn);
      Matter.Body.setVelocity(worldSetup.bodies.tp, { x: 0.1, y: -0.1 }); // tiny nudge
      Matter.Body.setAngularVelocity(worldSetup.bodies.tp, 0);
    }
    
    return worldSetup;
  });
  const { engine, world, bodies } = enginePkg;

  // Simple scoring functions (no persistent storage for now)
  const addScore = () => {
    const newScore = score + 1;
    setScore(newScore);
    
    // Update high score if needed (session only)
    if (newScore > highScore) {
      setHighScore(newScore);
    }
  };

  // Update the ref when addScore changes
  useEffect(() => {
    addScoreRef.current = addScore;
  }, [score, highScore]);

  const showGameOver = () => {
    setGameOverVisible(true);
  };

  // Debug: Dump static bodies to find invisible walls
  const dumpStatics = (engine) => {
    const bodies = Matter.Composite.allBodies(engine.world);
    const statics = bodies.filter(b => b.isStatic);
    console.log("STATIC BODIES:", statics.length);
    statics.forEach((b, i) => {
      const bb = b.bounds;
      console.log(
        `#${i} label=${b.label || "(none)"} x=${b.position.x.toFixed(1)} y=${b.position.y.toFixed(1)} ` +
        `w=${(bb.max.x - bb.min.x).toFixed(1)} h=${(bb.max.y - bb.min.y).toFixed(1)}`
      );
    });
  };

  // Keep last aim from AimPad
  const lastAimRef = useRef(null);

  // Bulletproof launch function
  const doLaunch = () => {
    const a = lastAimRef.current;
    const tp = bodies?.tp;                           // stick to ONE body reference
    if (!a || !tp) { return; }

    // spawn at pad center (with fallback)
    const spawn = { 
      x: a.origin?.x || WIDTH / 2, 
      y: a.origin?.y || HEIGHT - 24 - 90 
    };



    // Ensure spawn coordinates are valid numbers
    if (!Number.isFinite(spawn.x) || !Number.isFinite(spawn.y)) {
      return;
    }

    // wake + place
    Matter.Body.setStatic(tp, false);
    Matter.Sleeping.set(tp, false);
    Matter.Body.setPosition(tp, spawn);
    Matter.Body.setVelocity(tp, { x: 0, y: 0 });
    Matter.Body.setAngularVelocity(tp, 0);

    // Verify the body position was set correctly
    const newPos = tp.position;
    if (!Number.isFinite(newPos.x) || !Number.isFinite(newPos.y)) {
      // Create a new body if the current one is corrupted
      const newTp = Matter.Bodies.circle(spawn.x, spawn.y, CONSTANTS.TP_RADIUS, {
        restitution: 0.45,
        friction: 0.05,
        frictionAir: 0.012,
        density: 0.0016,
        label: 'TP'
      });
      
      // Remove old body and add new one
      Matter.World.remove(world, tp);
      Matter.World.add(world, newTp);
      
      // Update the reference
      bodies.tp = newTp;
      
      // Set velocity on the new body
      const rawP = a.power || 0;
      const p = Math.max(0.25, Math.min(1, rawP));
      const SPEED = 16.2;  // Reduced acceleration (10% less) for smoother launch
      const vx = (a.dir?.x || 0) * SPEED * p;
      const vy = -(Math.abs(a.dir?.y || 0)) * SPEED * p;
      
      Matter.Body.setVelocity(newTp, { x: vx, y: vy });
      Matter.Body.setAngularVelocity(newTp, 0.2 * p);
      
      setTpPos(spawn);
      setTpVisible(true);
      
      return;
    }

    // power from AimPad drag distance; add a safe minimum
    const rawP = a.power || 0;
    const p = Math.max(0.25, Math.min(1, rawP));     // TEMP min power 25%
    const SPEED = 16.2;  // Reduced acceleration (10% less) for smoother launch

    // portrait: up is negative Y
    const vx = (a.dir?.x || 0) * SPEED * p;
    const vy = -(Math.abs(a.dir?.y || 0)) * SPEED * p;

    Matter.Body.setVelocity(tp, { x: vx, y: vy });
    Matter.Body.setAngularVelocity(tp, 0.2 * p);



    // FIRST-FRAME SYNC + show sprite in the SAME component that renders it
    // Force immediate sync to prevent afterUpdate from overwriting
    setTpPos(spawn);
    setTpVisible(true);
  };

  const stateRef = useRef({
    isCharging: false,
    charge: 0,
    chargeDir: 1,
    aiming: false,
    dragStart: { x: CONSTANTS.START_X, y: CONSTANTS.START_Y },
    dragCurrent: { x: CONSTANTS.START_X, y: CONSTANTS.START_Y },
    turnOver: false,
    // AimPad controls
    padActive: false,
    padPower: 0,
    padOrigin: null,
    padVel: null,
  });

  // Load sounds
  useEffect(() => {
    loadSounds();
    return () => {
      if (dingSound) {
        dingSound.unloadAsync();
      }
    };
  }, []);

  // Apply mute state to loaded sounds
  useEffect(() => {
    const applyVolume = async () => {
      if (dingSound) {
        try {
          await dingSound.setVolumeAsync(isMuted ? 0 : 1);
        } catch (e) {
          // ignore
        }
      }
      try {
        await Audio.setIsEnabledAsync(!isMuted);
      } catch {}
    };
    applyVolume();
  }, [isMuted]);

  // Game timer
  useEffect(() => {
    let timer;
    if (gameMode === 'quick-flush' && timeLeft > 0) {
      timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (gameMode === 'quick-flush' && timeLeft === 0) {
      onGameComplete(score);
    } else if (gameMode === 'endless-plunge' && misses >= 3) {
      onGameComplete(score);
    }
    return () => clearTimeout(timer);
  }, [timeLeft, misses, gameMode, score]);

  // Collision handling: if tp hits ground, mark turn over
  useEffect(() => {
    const onCollide = (e) => {
      const pairs = e.pairs || [];
      for (const p of pairs) {
        const labels = [p.bodyA.label, p.bodyB.label];
        if (labels.includes('toiletPaper') && labels.includes('ground')) {
          stateRef.current.turnOver = true;
          setMisses(prev => prev + 1);
        }
        if (labels.includes('toiletPaper') && labels.includes('toilet')) {
          setScore(prev => prev + 3);
          if (!isMuted) {
            playDingSound();
          }
          // Let TP fall naturally after scoring
          // No position reset - let physics handle it
        }
      }
    };
    Matter.Events.on(engine, 'collisionStart', onCollide);
    return () => Matter.Events.off(engine, 'collisionStart', onCollide);
  }, [engine, bodies.tp]);

  // After a turn ends, reset the paper
  useEffect(() => {
    let raf;
    const loop = () => {
      if (stateRef.current.turnOver) {
        // Let TP fall naturally, just reset UI state
        stateRef.current.turnOver = false;
        stateRef.current.isCharging = false;
        stateRef.current.aiming = false;
        stateRef.current.charge = 0;
        stateRef.current.chargeDir = 1;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [bodies.tp]);

  // Oscillating charge system for power meter
  useEffect(() => {
    let raf;
    const step = () => {
      // run on RAF/timer; ONLY mutate while isCharging
      if (stateRef.current.isCharging) {
        let c = (stateRef.current.charge ?? 0) + (stateRef.current.chargeDir ?? 1) * 120 * (1/60);
        if (c >= 100) { c = 100; stateRef.current.chargeDir = -1; }
        if (c <= 0)   { c = 0;   stateRef.current.chargeDir =  1; }
        stateRef.current.charge = c;
      }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Physics runner and position mirroring
  useEffect(() => {
    const engine = enginePkg.engine;

    
    const runner = Matter.Runner.create();
    Matter.Runner.run(runner, engine);

    engine.world.gravity.x = 0;
    engine.world.gravity.y = CONSTANTS.GRAVITY_Y;
    
    let updateCount = 0;
    Matter.Events.on(engine, "afterUpdate", () => {
      updateCount++;
      
      const tp = bodies?.tp;
      if (!tp) {
        return;
      }
      const p = tp.position;
      
      // Always update tpPos if TP is visible and position is valid
      if (tpVisible && Number.isFinite(p.x) && Number.isFinite(p.y)) {
        setTpPos({ x: p.x, y: p.y });
      }
      
      // Hide TP when it falls off screen or stops moving
      if (tpVisible && tp.position.y > HEIGHT + 100) {
        setTpVisible(false);
      }
      
      // Update toilet position to match bowl colliders
      const bowlBodies = bodies?.bowlBodies;
      if (bowlBodies && Number.isFinite(bowlBodies.centerX)) {
        setToiletPos({ 
          x: bowlBodies.centerX, 
          y: HEIGHT * 0.35 
        });
      }
    });

    return () => {
      Matter.Events.off(engine, "afterUpdate");
      Matter.Engine.clear(engine);
    };
  }, [enginePkg, bodies.tp]);

  // Input handled via AimPad
  const systems = [Physics, CollisionSystem, MovingToiletSystem];

  const [tick, setTick] = useState(0);
  useEffect(() => {
    // Force a slow UI refresh for HUD ~30fps without spamming state
    const id = setInterval(() => setTick((t) => t + 1), 33);
    setReady(true);
    
    return () => clearInterval(id);
  }, []);

  const state = stateRef.current;

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <View style={styles.container}>
      {/* Game UI */}
      <View style={styles.gameUI}>
        <View style={styles.actionsRow}>
          <TouchableOpacity accessibilityLabel="Settings" onPress={() => setSettingsVisible(true)} style={styles.iconButton}>
            <Ionicons name="settings-sharp" size={22} color="#343a40" />
          </TouchableOpacity>
          <View style={styles.actionsCenter}>
            <View style={styles.scoreContainer}>
              <Text style={styles.scoreLabel}>Score</Text>
              <Text style={styles.scoreValue}>{score}</Text>
            </View>
            {gameMode === 'quick-flush' && (
              <View style={styles.timeContainer}>
                <Text style={styles.timeLabel}>Time</Text>
                <Text style={styles.timeValue}>{formatTime(timeLeft)}</Text>
              </View>
            )}
            {gameMode === 'endless-plunge' && (
              <View style={styles.missesContainer}>
                <Text style={styles.missesLabel}>Misses</Text>
                <Text style={styles.missesValue}>{misses}/3</Text>
              </View>
            )}
          </View>
          <TouchableOpacity accessibilityLabel="Toggle sound" onPress={() => setIsMuted(m => !m)} style={styles.iconButton}>
            <Ionicons name={isMuted ? 'volume-mute' : 'volume-high'} size={22} color={isMuted ? '#adb5bd' : '#343a40'} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Game Area */}
      <ImageBackground 
        source={require('../../assets/game_background.png')} 
        style={styles.gameArea}
        resizeMode="stretch"
      >
        <GameEngine
          ref={gameRef}
          style={styles.game}
          systems={systems}
          entities={{
            physics: { engine, world, bodies },
            state,
            tp: { body: bodies.tp, renderer: null }, // TP now rendered separately
          }}
        >
          {/* HUD removed: old charge bar + trajectory indicator */}
        </GameEngine>

        {/* New overlay + AimPad */}
        <TrajectoryOverlay
          origin={state.padOrigin || { x: WIDTH / 2, y: HEIGHT - 24 - 56 }}
          vel={state.padVel || null}
          gravityY={CONSTANTS.GRAVITY_Y}
          visible={!!state.padActive}
          steps={26}
          dt={1/30}
        />

        <AimPad
          radius={74.25}
          onAim={({ dir, power, active, origin }) => {
            lastAimRef.current = { dir, power, origin };
            stateRef.current.padActive = !!active;

            // start charge only while aiming
            if (active && !stateRef.current.isCharging) {
              stateRef.current.isCharging = true;
              stateRef.current.charge = 0;        // start from 0 each aim
              stateRef.current.chargeDir = 1;     // ping-pong up first
            }
          }}
          onRelease={() => {
            stateRef.current.isCharging = false;  // <-- stop the meter
            stateRef.current.charge = 0;          // reset for next shot
            doLaunch();                            // call your launch fn (below)
          }}
        />

        {/* Debug: Visualize static bodies (temporarily disabled) */}
        {/* <StaticBodiesOverlay engine={engine} /> */}
        
        {/* Debug: Show bowl hitbox (temporarily disabled) */}
        {/* <BowlHitboxOverlay engine={engine} /> */}

        {/* Toilet sprite (visual only, no physics) */}
        <View style={{
          position: 'absolute',
          left: toiletPos.x - 160,
          top: toiletPos.y - 160,
          width: 320,
          height: 320,
          zIndex: 10,
        }}>
          <Image
            source={require('../../assets/toilet.png')}
            style={{ width: '100%', height: '100%' }}
            resizeMode="contain"
          />
        </View>

        {/* TP sprite — bulletproof rendering with rotation */}
        {tpVisible && Number.isFinite(tpPos.x) && Number.isFinite(tpPos.y) && (
          <Image
            source={require('../../assets/tp.png')}   // verify path!
            style={{ 
              position:'absolute', 
              left: tpPos.x - 28, 
              top: tpPos.y - 28, 
              width:56, 
              height:56, 
              zIndex:20,
              transform: [{ rotate: `${bodies.tp.angle * (180 / Math.PI)}deg` }] // Convert radians to degrees
            }}
            resizeMode="contain"
            onLoad={() => console.log('TP image loaded successfully')}
            onError={(error) => {
              console.error('TP image failed to load:', error);
              // Only show red circle if image fails to load
            }}
          />
        )}
        
        {/* Debug: Show TP position as a simple colored circle ONLY if image fails */}
        {/* {tpVisible && Number.isFinite(tpPos.x) && Number.isFinite(tpPos.y) && (
          <View
            style={{
              position: 'absolute',
              left: tpPos.x - 28,
              top: tpPos.y - 28,
              width: 56,
              height: 56,
              borderRadius: 28,
              backgroundColor: '#FF6B6B',
              borderWidth: 2,
              borderColor: '#fff',
              zIndex: 19
            }}
          />
        )} */}


      </ImageBackground>

      <Modal
        transparent
        animationType="fade"
        visible={settingsVisible}
        onRequestClose={() => setSettingsVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Settings</Text>
            <Text style={styles.modalText}>Coming soon.</Text>
            <TouchableOpacity onPress={() => setSettingsVisible(false)} style={styles.modalButton}>
              <Text style={styles.modalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Game Over Modal */}
      <Modal
        transparent
        animationType="fade"
        visible={gameOverVisible}
        onRequestClose={() => setGameOverVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Game Over!</Text>
            <Text style={styles.modalText}>Final Score: {score}</Text>
            <Text style={styles.modalText}>High Score: {highScore}</Text>
            {score === highScore && score > 0 && (
              <Text style={styles.newRecordText}>🎉 New Record! 🎉</Text>
            )}
            <TouchableOpacity onPress={() => {
              setGameOverVisible(false);
              onGameComplete && onGameComplete();
            }} style={styles.modalButton}>
              <Text style={styles.modalButtonText}>Play Again</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

/******************** Styles ********************/
const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#0e0f12' 
  },
  gameUI: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
    padding: 20,
    paddingTop: 80,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  actionsCenter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    gap: 24,
  },
  scoreContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 80,
  },
  timeContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 100,
  },
  actionsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconButton: {
    paddingHorizontal: 8,
    paddingVertical: 6,
  },
  scoreLabel: {
    fontSize: 14,
    color: '#6c757d',
    fontWeight: '600',
  },
  scoreValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4ECDC4',
  },

  timeLabel: {
    fontSize: 14,
    color: '#6c757d',
    fontWeight: '600',
  },
  timeValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF6B6B',
  },
  missesContainer: {
    alignItems: 'center',
  },
  missesLabel: {
    fontSize: 14,
    color: '#6c757d',
    fontWeight: '600',
  },
  missesValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF6B6B',
  },
  gameArea: {
    flex: 1,
    position: 'relative',
  },
  game: { 
    flex: 1, 
    backgroundColor: 'transparent' 
  },
  shootWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  shootButton: {
    width: 110,
    height: 110,
    alignItems: 'center',
    justifyContent: 'center',
  },
  toiletContainer: {
    position: 'absolute',
    width: 270,
    height: 240,
    zIndex: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  toiletImage: {
    width: 270,
    height: 240,
  },
  titleWrap: { 
    position: 'absolute', 
    top: 20, 
    width: '100%', 
    alignItems: 'center' 
  },
  title: { 
    color: '#fff', 
    fontSize: 22, 
    fontWeight: '700' 
  },
  subtitle: { 
    color: '#9aa3b2', 
    fontSize: 12, 
    marginTop: 4 
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCard: {
    width: '80%',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 8,
    color: '#212529',
  },
  modalText: {
    fontSize: 14,
    color: '#495057',
    marginBottom: 16,
  },
  modalButton: {
    backgroundColor: '#4ECDC4',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  modalButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  newRecordText: {
    color: '#FFD700',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 10,
  },
  // Old aim and charge styles removed - now using imported components
});
